
Blockly.ke_red_led = 'red_led';
Blockly.ke_dual_led = 'dual_led';
Blockly.ke_yellow_led='yellow_led';
Blockly.ke_white_led='white_led';
Blockly.ke_3W='3W_led';
Blockly.ke_led_green='green_led';

Blockly.ke_msgb_led1='The magic light cup_LED';
Blockly.ke_msgb_sor1='The magic light cup sensor';
Blockly.ke_shouzhi1='Finger heart rate';
Blockly.ke_jg1='laser';

Blockly.Kids_anologWrite = 'anologWrite';
Blockly.Kids_value = 'value';


Blockly.Kids_ON = 'HIGH';
Blockly.Kids_OFF = 'LOW';
Blockly.Kids_anologWrite = 'anologWrite';

Blockly.Kids_iic = 'PIN：SDA# A4, SCL# A5';
Blockly.Kids_rot = 'button_PIN';
Blockly.Kids_rot_count = 'count';
Blockly.Kids_bits = 'string';
Blockly.Kids_pin = 'PIN';

Blockly.Kids_iic_pin = 'PIN #SDA:A4,#SCL:A5';
Blockly.Kids_lcd_p = 'LCD';
Blockly.Kids_shilihua = 'Instantiation name';
Blockly.Kids_size = 'font size';

Blockly.Kids_printcount = 'Display digits';
Blockly.ke_string = 'display character';

Blockly.Kids_lcd_left = 'LCD_Scroll to the left';
Blockly.Kids_lcd_right = 'LCD_Scroll to the right';

Blockly.ke_TM1637='4 digit 8-segment LED digital';
Blockly.ke_ws='digit';
Blockly.ke_begin='Display position';
Blockly.ke_fill0='add 0?';
Blockly.ke_light='Brightness0~7';
Blockly.ke_XY='Show or hide';
Blockly.ke_L='left';
Blockly.ke_R='right';
Blockly.ke_MH='colon';
Blockly.ke_value='value';

Blockly.ke_oled_init = 'OLED_init';
Blockly.ke_oled_piexl = 'OLED_point coordinates';
Blockly.ke_oled_x = 'column';
Blockly.ke_oled_y = 'row';
Blockly.ke_oled_cong = 'from';
Blockly.ke_oled_dao = 'to';
Blockly.ke_oled_kai = 'initial point';
Blockly.ke_oled_kuan = 'width';
Blockly.ke_oled_chang = 'height';
Blockly.ke_oled_angle1 = 'angle1';
Blockly.ke_oled_angle2 = 'angle2';
Blockly.ke_oled_angle3 = 'angle3';

Blockly.ke_oled_line = 'OLED_line';
Blockly.ke_oled_rect = 'OLED_hollow rectangle';
Blockly.ke_oled_fil_lrect = 'OLED_solid rectangle';
Blockly.ke_oled_r_rect = 'OLED_hollow rounded rectangle';
Blockly.ke_oled_r_fill_rect = 'OLED_solid rounded rectangle';
Blockly.ke_oled_circle = 'OLED_hollow circle  Center coordinates';
Blockly.ke_oled_circle_radius = 'Circle radius';
Blockly.ke_oled_radius = 'Corner radius';
Blockly.ke_oled_fill_circle = 'OLED_solid circle  Center coordinates';
Blockly.ke_oled_triangle = 'OLED_hollow triangle';
Blockly.ke_oled_fill_triangle = 'OLED_solid triangle';
Blockly.ke_oled_string1 = 'OLED_displays a string or number';
Blockly.ke_oled_weizhi = 'display position';
Blockly.ke_oled_print = 'display';
Blockly.ke_oled_clear = 'OLED_clear';


Blockly.MIXLY_ke_LED1='Piranha LED';
Blockly.MIXLY_ke_LED2='Red Piranha LED';
Blockly.MIXLY_ke_LED3='Green Piranha LED';
Blockly.MIXLY_ke_LED4='Yellow Piranha LED';
Blockly.MIXLY_ke_LED5='Blue Piranha LED';
Blockly.MIXLY_ke_LED01='Straw cap LED';
Blockly.MIXLY_ke_LED02='Red Straw cap LED';
Blockly.MIXLY_ke_LED03='Green Straw cap LED';
Blockly.MIXLY_ke_LED04='Yellow straw cap LED';
Blockly.MIXLY_ke_LED05='Blue Straw cap LED';
Blockly.MIXLY_ke_QCD='Colorful lights';
Blockly.MIXLY_ke_RGB='RGB';

Blockly.MIXLY_ke_BUZZER1='Active buzzer';
Blockly.MIXLY_ke_BUZZER2='Passive Buzzer';
Blockly.MIXLY_ke_RELAY='Relay';
Blockly.MIXLY_ke_MOTOR='Fan';
Blockly.MIXLY_ke_MOTOR01='geared motor';
Blockly.MIXLY_ke_SERVO='servo';
Blockly.MIXLY_ke_TB6612='TB6612motor';
Blockly.MIXLY_H='front';
Blockly.MIXLY_L='back';

Blockly.MIXLY_ke_2812RGB='Full Color Led';

Blockly.MIXLY_ke_IR_G='PIR Sensor';
Blockly.MIXLY_ke_FLAME='Flame Sensor';
Blockly.MIXLY_ke_HALL='Hall Sensor';
Blockly.MIXLY_ke_CRASH='Crash Sensor';
Blockly.MIXLY_ke_BUTTON='Button';
Blockly.MIXLY_ke_TUOCH='Capacitive Touch';
Blockly.MIXLY_ke_KNOCK='Knock Sensor';
Blockly.MIXLY_ke_TILT='Tilt Sensor';
Blockly.MIXLY_ke_SHAKE='Vibration Sensor';
Blockly.MIXLY_ke_REED_S='Reed Switch Sensor';
Blockly.MIXLY_ke_TRACK='Tracking Sensor';
Blockly.MIXLY_ke_AVOID='Obstacle Avoidance MSensor';
Blockly.MIXLY_ke_LIGHT_B='Light Interrupt Sensor';
Blockly.MIXLY_ke_ROT='Rotation';


Blockly.MIXLY_ke_ANALOG_T='Analog Temperature Sensor';
Blockly.MIXLY_ke_SOUND='Sound Sensor';
Blockly.MIXLY_ke_LIGHT='photosensitive Sensor';
Blockly.MIXLY_ke_WATER='Water Level Sensor';
Blockly.MIXLY_ke_SOIL='Soil Sensor';
Blockly.MIXLY_ke_POTENTIOMETER='rotational potentiometer';
Blockly.MIXLY_ke_LM35='LM35 Temperature Sensor';
Blockly.MIXLY_ke_SLIDE_POTENTIOMETER='slide potentiometer';
Blockly.MIXLY_ke_TEMT6000='TEMT6000 Ambient Light';
Blockly.MIXLY_ke_STEAM='water vapor sensor';
Blockly.MIXLY_ke_FILM_P='Thin-film Pressure Sensor';
Blockly.MIXLY_ke_JOYSTICK='Joystick Sensor';
Blockly.MIXLY_ke_JOYSTICK_btn='Joystick_button';
Blockly.MIXLY_ke_SMOKE='Smoke Sensor';
Blockly.MIXLY_ke_ALCOHOL='Alcohol Sensor';
Blockly.MIXLY_ke_MQ135='MQ135 Air Quality';
Blockly.MIXLY_ke_18B20='18B20 Temperature Sensor';
Blockly.MIXLY_ke_18B20_R='Getting temperature';
Blockly.MIXLY_ke_DHT11='temperature and humidity Sensor';
Blockly.MIXLY_ke_BMP180='BMP180 altimeter Sensor';
Blockly.MIXLY_ke_BMP180_T='temperature';
Blockly.MIXLY_ke_BMP180_A='atmosphere';
Blockly.MIXLY_ke_BMP180_H='height above sea level ';

Blockly.MIXLY_ke_BMP280='BMP280 altimeter Sensor';
Blockly.MIXLY_ke_BMP280_T='temperature';
Blockly.MIXLY_ke_BMP280_A='atmosphere';
Blockly.MIXLY_ke_BMP280_H='height above sea level';

Blockly.MIXLY_ke_SR01='SR01 Ultrasound Module';
Blockly.MIXLY_ke_3231='DS3231 clock';
Blockly.MIXLY_ke_ADXL345='Acceleration Sensor';


Blockly.MIXLY_ke_OLED='OLED_displays a string or number';
Blockly.MIXLY_ke_1602LCD='IIC1602LCD';
Blockly.MIXLY_ke_2004LCD='IIC2004LCD';
Blockly.MIXLY_ke_print1='print line1';
Blockly.MIXLY_ke_print2='print line2';
Blockly.MIXLY_ke_print3='print line3';
Blockly.MIXLY_ke_print4='print line4';

Blockly.MIXLY_ke_MATRIX='8*8 dot matrix';
Blockly.MIXLY_ke_TM1637='4 digit 8-segment LED digital';
Blockly.MIXLY_ke_TM1637_C='digit';
Blockly.MIXLY_ke_TM1637_P='display position';
Blockly.MIXLY_ke_TM1637_Fill='add 0?';
Blockly.MIXLY_ke_TM1637_light='brightness 0~7';
Blockly.MIXLY_ke_TM1637_xy='show or hide';
Blockly.MIXLY_ke_TM1637_left='left';
Blockly.MIXLY_ke_TM1637_maohao='colon';
Blockly.MIXLY_ke_TM1637_right='right';
Blockly.MIXLY_ke_value='value';


Blockly.MIXLY_ke_IR_E='Infrared Transmitter Module';
Blockly.MIXLY_ke_IR_R='Infrared Receiver Module';
Blockly.MIXLY_ke_W5100='W5100 Ethernet Module';
Blockly.MIXLY_ke_BLUETOOTH='Bluetooth 2.0 Module';
Blockly.MIXLY_ke_read='Received signal';


//Blockly.MIXLY_ke_kzsc = 'Control output';

Blockly.MIXLY_ke_Count='count';

Blockly.MIXLY_ke_YEAR = 'year';
Blockly.MIXLY_ke_MONTH = 'month';
Blockly.MIXLY_ke_DAY = 'day';
Blockly.MIXLY_ke_HOUR = 'hour';
Blockly.MIXLY_ke_MINUTE = 'minute';
Blockly.MIXLY_ke_SECOND = 'second';
Blockly.MIXLY_ke_WEEK = 'week';

Blockly.MIXLY_ke_angle = 'angle';

Blockly.kids_Ode_to_joy = "Ode_to_joy";
Blockly.kids_birthday = "birthday";

Blockly.kids_tone = "tone";
Blockly.kids_beat = "beat";
Blockly.kids_play_tone = "play_tone";
Blockly.kids_notone = "no_tone";

Blockly.kids_ADkey = "7 key module";